package fm.mrc.quantumexplorers

import android.app.Application
import dagger.hilt.android.HiltAndroidApp

@HiltAndroidApp
class QuantumExplorersApp : Application() 